package com.app.pojos;

public enum QualificationType {
DEGREE,DIPLOMA
}
