package com.app.pojos;

public enum GenderType {
	MALE,FEMALE,OTHER

}
