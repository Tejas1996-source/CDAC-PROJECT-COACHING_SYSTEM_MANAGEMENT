
export class Course {
   
    course_id: number;
    course_name: string;
    batch_size:number;
    fees:number;
    start_date:string;
    end_date:string;
    "faculty":{
        
    faculty_name: string,
    address: string,
    contact_no: string
    }
  
   constructor() {}
   
   


}
/*export class schedule
{
    classname:string;
    subject:string;
    topic:string;
    class_date:Date;
    class_Link:string;
    "teacher":{
        teacher_id:number;
    }
constructor()
{
    
}

}
 */
