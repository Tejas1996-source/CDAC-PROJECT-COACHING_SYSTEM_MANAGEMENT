

export class Feed {
    feedback_id:number;
    rating:number;
    comments:string;
    enroll:{
        enroll_id:number;
    }
   constructor() {}
   
   


}