

export class Student {
   
     email: string;
     password: string;
   
    constructor() {}
    
    


}

